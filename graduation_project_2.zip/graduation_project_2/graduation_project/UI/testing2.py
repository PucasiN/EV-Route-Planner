from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import (QApplication, QWidget, QLabel, QFrame, 
                            QMessageBox, QVBoxLayout, QHBoxLayout, 
                            QGridLayout, QGroupBox, QPushButton, 
                            QTextEdit, QSpinBox, QComboBox, 
                            QProgressBar)
from PyQt6.QtGui import QFont
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import pandas as pd
import os

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1000, 650)
        Form.setWindowTitle("EV Route Planner")
        
        # Main layout with some spacing
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        
        # Create header banner with enhanced title
        self.header = QWidget(Form)
        self.header.setMinimumSize(QtCore.QSize(0, 100))
        self.header.setStyleSheet("background-color: #4CAF50;")
        
        # Main header layout
        header_layout = QVBoxLayout(self.header)
        header_layout.setContentsMargins(20, 10, 20, 10)
        header_layout.setSpacing(5)
        
        # Main title with larger, more prominent font
        self.title_label = QLabel("EV ROUTE PLANNER", self.header)
        self.title_label.setStyleSheet("""
            color: white;
            font-weight: bold;
            qproperty-alignment: AlignCenter;
        """)
        self.title_label.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        
        # Subtitle with improved styling
        self.subtitle = QLabel("Plan Your Electric Vehicle Journey Efficiently", self.header)
        self.subtitle.setStyleSheet("""
            color: #e8f5e9;
            font-size: 14pt;
            qproperty-alignment: AlignCenter;
            font-weight: 500;
        """)
        self.subtitle.setFont(QFont("Segoe UI", 12))
        
        # Add decorative line
        self.decorative_line = QFrame(self.header)
        self.decorative_line.setFrameShape(QFrame.Shape.HLine)
        self.decorative_line.setStyleSheet("""
            QFrame {
                color: rgba(255, 255, 255, 0.3);
                background-color: rgba(255, 255, 255, 0.3);
                border: none;
                height: 2px;
                margin: 5px 50px;
            }
        """)
        
        header_layout.addWidget(self.title_label)
        header_layout.addWidget(self.decorative_line)
        header_layout.addWidget(self.subtitle)
        
        self.verticalLayout.addWidget(self.header)

        # Main content widget with grey background
        self.contentWidget = QWidget(Form)
        self.contentWidget.setStyleSheet("background-color: #f5f5f5;")
        self.contentLayout = QVBoxLayout(self.contentWidget)
        self.contentLayout.setContentsMargins(20, 20, 20, 20)
        self.contentLayout.setSpacing(15)
        
        # Inputs group box - white with grey border
        self.groupBox = QGroupBox(parent=self.contentWidget)
        self.groupBox.setTitle("Journey Parameters")
        self.groupBox.setStyleSheet("""
            QGroupBox {
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
                color: #555;
                background-color: white;
                font-size: 12pt;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #555;
            }
        """)
        
        self.gridLayout = QGridLayout(self.groupBox)
        self.gridLayout.setVerticalSpacing(12)
        self.gridLayout.setHorizontalSpacing(20)

        # Battery level widget
        self.label_battery = QLabel("Battery Level (%)", parent=self.groupBox)
        self.battery_widget = QWidget(parent=self.groupBox)
        self.battery_layout = QHBoxLayout(self.battery_widget)
        self.battery_layout.setContentsMargins(0, 0, 0, 0)
        self.battery_layout.setSpacing(10)
        self.spin_battery = QSpinBox(parent=self.battery_widget)
        self.spin_battery.setRange(0, 100)
        self.spin_battery.setValue(50)
        self.spin_battery.setSuffix("%")
        self.progress_battery = QProgressBar(parent=self.battery_widget)
        self.progress_battery.setRange(0, 100)
        self.progress_battery.setValue(self.spin_battery.value())
        self.progress_battery.setTextVisible(True)
        self.progress_battery.setStyleSheet("""
            QProgressBar {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                text-align: center;
                height: 20px;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                width: 10px;
            }
        """)
        self.battery_layout.addWidget(self.spin_battery)
        self.battery_layout.addWidget(self.progress_battery)
        self.gridLayout.addWidget(self.label_battery, 0, 0)
        self.gridLayout.addWidget(self.battery_widget, 0, 1)

        # Temperature input
        self.label_temp = QLabel("Temperature (°C)", parent=self.groupBox)
        self.spin_temp = QSpinBox(parent=self.groupBox)
        self.spin_temp.setRange(-20, 50)
        self.gridLayout.addWidget(self.label_temp, 1, 0)
        self.gridLayout.addWidget(self.spin_temp, 1, 1)

        # Desired battery level
        self.label_desired = QLabel("Desired Battery (%)", parent=self.groupBox)
        self.spin_desired = QSpinBox(parent=self.groupBox)
        self.spin_desired.setRange(0, 100)
        self.spin_desired.setValue(80)
        self.spin_desired.setSuffix("%")
        self.gridLayout.addWidget(self.label_desired, 2, 0)
        self.gridLayout.addWidget(self.spin_desired, 2, 1)

        # Start city
        self.label_start = QLabel("Start City", parent=self.groupBox)
        self.combo_start = QComboBox(parent=self.groupBox)
        self.combo_start.addItems(["Istanbul", "Ankara", "Antalya", "Kocaeli", "Konya", "Izmir", "Bursa"])
        self.gridLayout.addWidget(self.label_start, 3, 0)
        self.gridLayout.addWidget(self.combo_start, 3, 1)

        # Destination city
        self.label_end = QLabel("Destination City", parent=self.groupBox)
        self.combo_end = QComboBox(parent=self.groupBox)
        self.combo_end.addItems(["Istanbul", "Ankara", "Antalya", "Kocaeli", "Konya", "Izmir", "Bursa"])
        self.gridLayout.addWidget(self.label_end, 4, 0)
        self.gridLayout.addWidget(self.combo_end, 4, 1)

        self.contentLayout.addWidget(self.groupBox)

        # Results group box
        self.groupBox_3 = QGroupBox(parent=self.contentWidget)
        self.groupBox_3.setTitle("Route Analysis Results")
        self.groupBox_3.setStyleSheet("""
            QGroupBox {
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
                color: #555;
                background-color: white;
                font-size: 12pt;
            }
        """)
        self.horizontalLayout = QHBoxLayout(self.groupBox_3)
        self.horizontalLayout.setSpacing(15)

        # Button column
        self.button_layout = QVBoxLayout()
        self.button_layout.setSpacing(10)

        # Style buttons with light green
        button_style = """
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 15px;
                font-weight: bold;
                min-width: 160px;
                font-size: 11pt;
            }
            QPushButton:hover {
                background-color: #43A047;
            }
            QPushButton:pressed {
                background-color: #388E3C;
            }
        """

        self.btn_stations = QPushButton("Number of Stations", parent=self.groupBox_3)
        self.btn_time = QPushButton("Total Travel Time", parent=self.groupBox_3)
        self.btn_charging = QPushButton("Charging Stations", parent=self.groupBox_3)
        self.btn_cost = QPushButton("Total Trip Cost", parent=self.groupBox_3)
        self.btn_all = QPushButton("Show All Results", parent=self.groupBox_3)
        self.btn_graph = QPushButton("View Route Graph", parent=self.groupBox_3)

        for btn in [self.btn_stations, self.btn_time, self.btn_charging, self.btn_cost, self.btn_all, self.btn_graph]:
            btn.setStyleSheet(button_style)
            self.button_layout.addWidget(btn)

        self.horizontalLayout.addLayout(self.button_layout)
        
        # Results display area
        self.label_all_output = QTextEdit(parent=self.groupBox_3)
        self.label_all_output.setPlaceholderText("Your route analysis results will appear here...")
        self.label_all_output.setReadOnly(True)
        self.label_all_output.setStyleSheet("""
            QTextEdit {
                background-color: white;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 12px;
                font-size: 11pt;
                color: #555;
            }
        """)
        self.horizontalLayout.addWidget(self.label_all_output)
        self.contentLayout.addWidget(self.groupBox_3)
        
        # Add status bar with light green
        self.status_bar = QFrame(Form)
        self.status_bar.setFrameShape(QFrame.Shape.StyledPanel)
        self.status_bar.setFrameShadow(QFrame.Shadow.Raised)
        self.status_bar.setStyleSheet("background-color: #4CAF50; color: white; padding: 5px;")
        self.status_label = QLabel("Ready to plan your EV journey!", self.status_bar)
        self.status_label.setStyleSheet("color: white;")
        
        status_layout = QHBoxLayout(self.status_bar)
        status_layout.addWidget(self.status_label)
        status_layout.setContentsMargins(10, 0, 10, 0)
        
        self.verticalLayout.addWidget(self.contentWidget)
        self.verticalLayout.addWidget(self.status_bar)
        
        # Connect signals
        self.spin_battery.valueChanged.connect(self.progress_battery.setValue)
        QtCore.QMetaObject.connectSlotsByName(Form)

# ... (Previous Ui_Form class remains unchanged) ...

# ... (Previous Ui_Form class remains unchanged) ...

class EVRoutePlanner(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.base_path = r"C:\Users\fayez\OneDrive - Gebze Teknik Üniversitesi\Year 4\Term 2\Bitirme Projesi\Newest UI"
        
        # Connect buttons
        self.ui.btn_stations.clicked.connect(self.show_stations)
        self.ui.btn_time.clicked.connect(self.show_time)
        self.ui.btn_charging.clicked.connect(self.show_charging)
        self.ui.btn_cost.clicked.connect(self.show_cost)
        self.ui.btn_all.clicked.connect(self.show_all)
        self.ui.btn_graph.clicked.connect(self.show_graph)  # Now connected to existing method
    
    def get_excel_path(self):
        """Generate file path based on selected cities"""
        start = self.ui.combo_start.currentText()
        end = self.ui.combo_end.currentText()
        filename = f"{start}-{end}.xlsx"
        return os.path.join(self.base_path, filename)
    
    def validate_file(self, path):
        """Check if file exists and is valid"""
        if not os.path.exists(path):
            QMessageBox.critical(
                self, 
                "File Not Found", 
                f"Route data file not found:\n{path}\n\n"
                "Please ensure you've selected valid cities and the route file exists."
            )
            self.ui.status_label.setText(f"Error: File not found - {os.path.basename(path)}")
            return False
        return True

    def read_excel_data(self):
        # Get dynamic path based on user selection
        self.excel_path = self.get_excel_path()
        
        # Validate file exists before processing
        if not self.validate_file(self.excel_path):
            return None
        
        data = {}
        try:
            # Read all sheets with proper index handling
            # For scalar values (single numbers)
            data['ns'] = self.read_scalar('NS')
            data['tt'] = self.read_scalar('TT')
            data['tc'] = self.read_scalar('TC')
            
            # For matrix data
            data['charge'] = self.read_matrix('charge')
            
            # Convert minutes to hours and minutes
            hours = data['tt'] // 60
            minutes = data['tt'] % 60
            data['tt_formatted'] = f"{int(hours)} hours {int(minutes)} minutes"
            
            return data
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Data Read Error", 
                f"Error processing route data:\n{str(e)}\n\n"
                "Please ensure the Excel file format is correct."
            )
            self.ui.status_label.setText(f"Error reading data from {os.path.basename(self.excel_path)}")
            return None

    def read_scalar(self, sheet_name):
        """Read a single value from a sheet"""
        df = pd.read_excel(self.excel_path, sheet_name=sheet_name, header=None)
        
        # Find the first numeric value in the entire sheet
        for row in df.values:
            for cell in row:
                try:
                    return float(cell)
                except (ValueError, TypeError):
                    continue
        raise ValueError(f"No numeric value found in sheet {sheet_name}")

    def read_matrix(self, sheet_name):
        """Read matrix data from a sheet, handling index columns"""
        df = pd.read_excel(self.excel_path, sheet_name=sheet_name)
        
        # Remove any "Unnamed" index columns
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
        
        # Convert to numeric, ignoring errors
        return df.apply(pd.to_numeric, errors='coerce')

    def show_stations(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Number of Charging Stations: {int(data['ns'])}"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed stations from {filename}")

    def show_time(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Total Travel Time: {data['tt_formatted']}"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed travel time from {filename}")

    def show_charging(self):
        if data := self.read_excel_data():
            # Filter stations with actual charging
            charged_stations = data['charge'][data['charge'] > 0].stack()
            
            # Format station information
            station_info = []
            for (segment, station), charge in charged_stations.items():
                station_info.append(
                    f"Segment {segment+1}, Station {station+1}: {charge:.2f} kWh"
                )
            
            self.ui.label_all_output.setText(
                "Charging Stations Along Route:\n\n" + 
                "\n".join(station_info) if station_info else 
                "No charging stations used on this route"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed charging info from {filename}")

    # ... (rest of the code remains the same) ...

    def show_cost(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Total Trip Cost: {data['tc']:.2f} TL"  # Changed $ to TL
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed trip cost from {filename}")

    def show_all(self):
        if data := self.read_excel_data():
            # Get current parameters from UI - moved outside try block
            current_battery = self.ui.spin_battery.value()
            current_temp = self.ui.spin_temp.value()
            desired_battery = self.ui.spin_desired.value()
            start_city = self.ui.combo_start.currentText()
            end_city = self.ui.combo_end.currentText()
            
            try:
                # Get charging station details
                charged_stations = data['charge'][data['charge'] > 0].stack()
                station_info = []
                for (s, t), c in charged_stations.items():
                    station_info.append(
                        f"  - Segment {int(s)+1}, Station {int(t)+1}: {c:.2f} kWh"
                    )
                
                # Battery data extraction
                battery_info = "  Battery data not available"
                try:
                    percentage_df = pd.read_excel(self.excel_path, sheet_name='percentage')
                    
                    # Remove any index columns
                    percentage_df = percentage_df.loc[:, ~percentage_df.columns.str.contains('^Unnamed')]
                    
                    # Find the first column that looks like percentage data
                    battery_levels = []
                    for col in percentage_df.columns:
                        if pd.api.types.is_numeric_dtype(percentage_df[col]):
                            battery_levels = percentage_df[col].tolist()
                            # Build battery info
                            battery_info = "\n".join(
                                [f"  - Segment {i+1}: {val:.1f}%" 
                                for i, val in enumerate(battery_levels)]
                            )
                            break  # Exit after first valid column
                    
                    if not battery_levels:
                        battery_info = "  No valid battery data found"
                except Exception as e:
                    battery_info = f"  Error reading battery data: {str(e)}"
                
                # Build the output string
                output_text = (
                    "EV Route Planner - Complete Analysis\n\n"
                    f"Route: {start_city} → {end_city}\n"
                    f"Data Source: {os.path.basename(self.excel_path)}\n\n"
                    f"Current Battery: {current_battery}%\n"
                    f"Desired Battery: {desired_battery}%\n"
                    f"Temperature: {current_temp}°C\n\n"
                    f"Number of Charging Stations: {int(data['ns'])}\n"
                    f"Total Travel Time: {data['tt_formatted']}\n"
                    f"Total Trip Cost: {data['tc']:.2f} TL\n\n"
                    "Charging Stations:\n" +
                    ("\n".join(station_info) if station_info else "  None") + "\n\n"
                    "Battery Levels by Segment:\n" +
                    battery_info
                )
                
                self.ui.label_all_output.setText(output_text)
                filename = os.path.basename(self.excel_path)
                self.ui.status_label.setText(f"Displayed full analysis from {filename}")
            
            except Exception as e:
                QMessageBox.critical(self, "Data Processing Error", f"Failed to process data:\n{str(e)}")
                self.ui.status_label.setText("Error displaying results")

    # Restored show_graph method - unchanged from original
    def show_graph(self):
        # Create sample data for the graph
        segments = list(range(1, 11))
        battery_levels = [90, 78, 65, 50, 40, 35, 32, 30, 28, 25]
        consumption = [2.5, 3.0, 3.8, 4.0, 3.6, 3.2, 2.8, 2.5, 2.0, 1.8]
        charging = [0, 10, 0, 0, 5, 0, 8, 0, 0, 6]

        # Create the figure and axes
        fig, ax1 = plt.subplots(figsize=(8, 5))
        ax1.plot(segments, battery_levels, color='#4CAF50', marker='o', label='Battery Level (kWh)', linewidth=2)
        ax2 = ax1.twinx()
        ax2.plot(segments, consumption, color='#757575', marker='s', label='Consumption (kWh)', linewidth=2)
        ax1.bar(segments, charging, color='#81C784', alpha=0.6, label='Charging (kWh)')

        # Set labels and title
        ax1.set_xlabel("Route Segment", fontsize=10)
        ax1.set_ylabel("Battery Level (kWh)", color='#4CAF50', fontsize=10)
        ax2.set_ylabel("Consumption (kWh)", color='#757575', fontsize=10)
        ax1.set_title("EV Route Analysis: Battery, Consumption and Charging", fontsize=12, pad=20)
        
        # Add legend
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')

        # Display the graph
        fig.tight_layout()
        plt.show()
        self.ui.status_label.setText("Displayed route analysis graph")


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = EVRoutePlanner()
    window.show()
    sys.exit(app.exec())
