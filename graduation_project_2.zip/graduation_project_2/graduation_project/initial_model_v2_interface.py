import tkinter as tk
from tkinter import ttk
from gams import *

# Variable isimleri
VARIABLE_NAME_MAPPING = {
    "x": "Charging Occured at Station",
    "E": "Energy Level In Segment",
    "Charge": "Charging Amount In Station",
    "z": "Total Cost In Terms Of Money and Time",
    "sure": "Spent Time In Station",
    "TC": "Total Cost",
    "TT": "Total Spent Time",
    "FC": "Fixed Cost",
    "f": "Energy Function",
    "NS": "Number of Stopped Stations",
    "Percentage": "Battery Percantage In Each Segment",
    "Qmax": "Max kW to be charged with limited speed up to 20% of the battery",
    "Nmax": "Max kW to be charged with normal speed between 20-80%",
    "Wmax": "Max kW to be charged with limited over 80% of the battery",
    "Nt": "Nt",
    "N": "Amount of Charge With Normal Speed",
    "Q": "Amount Of Charge With Limited Speed Up To 20% of the battery",
    "W": "Amount Of Charge With Limited Speed over 80% of the battery",
    
    
    
}

# GAMS çağırma fonksiyonu
def run_gams_and_get_output():
    ws = GamsWorkspace()
    model_path = "C:\\graduation_project\\initial_model.gms"
    job = ws.add_job_from_file(model_path)
    opt = ws.add_options()
    job.run(opt)

    # sonuçları listeye atma
    variables = []
    scalars = []

    for symbol in job.out_db:
        if isinstance(symbol, GamsVariable):  
            for rec in symbol:
                if rec.level != 0:  # variable kontrol
                    var_name = VARIABLE_NAME_MAPPING.get(symbol.name, symbol.name)
                    variables.append(f"{var_name} {rec.keys}: Amount={rec.level}")
        
        elif isinstance(symbol, GamsParameter):  # input verileri
            if len(symbol.domains) == 0:  
                for rec in symbol:
                    scalars.append(f"{symbol.name}: Value={rec.value}")
    
    return variables, scalars

# arayüz
def create_gui():
    def update_output():
        
        output_list.delete(0, tk.END)  # sonuçları temizle
        scalar_list.delete(0, tk.END)  # output temizle

        variables, scalars = run_gams_and_get_output()

        # variable yazdırma
        if variables:
            output_list.insert(tk.END, "=== Variables ===")
            for var in variables:
                output_list.insert(tk.END, var)
        else:
            output_list.insert(tk.END, "Variables: Sıfırdan farklı değer yok.")

        # input yazdırma
        if scalars:
            scalar_list.insert(tk.END, "=== Conditions ===")
            for scalar in scalars:
                scalar_list.insert(tk.END, scalar)
        else:
            scalar_list.insert(tk.END, "Conditions: Hiç değer bulunamadı.")

    # window
    root = tk.Tk()
    root.title("Route Decision Making Support Unit")
    root.geometry("800x600")

    # title
    title_label = tk.Label(root, text="Outputs", font=("Arial", 16))
    title_label.pack(pady=10)

    # variable boxları
    output_frame = tk.Frame(root)
    output_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    scrollbar = tk.Scrollbar(output_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    output_list = tk.Listbox(output_frame, font=("Courier", 12), yscrollcommand=scrollbar.set)
    output_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.config(command=output_list.yview)

    # input boxları
    scalar_frame = tk.Frame(root)
    scalar_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    scalar_scrollbar = tk.Scrollbar(scalar_frame)
    scalar_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    scalar_list = tk.Listbox(scalar_frame, font=("Courier", 12), yscrollcommand=scalar_scrollbar.set)
    scalar_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scalar_scrollbar.config(command=scalar_list.yview)

  
    run_button = ttk.Button(root, text="Run", command=update_output)
    run_button.pack(pady=10)

    
    root.mainloop()


if __name__ == "__main__":
    create_gui()

