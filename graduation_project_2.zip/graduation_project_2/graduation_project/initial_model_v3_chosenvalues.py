import tkinter as tk
from tkinter import ttk, filedialog
from gams import *

# Variable isimleri
VARIABLE_NAME_MAPPING = {
    "x": "Charging Occured at Station",
    "E": "Energy Level In Segment",
    "Charge": "Charging Amount In Station",
    "z": "Total Cost In Terms Of Money and Time",
    "sure": "Spent Time In Station",
    "TC": "Total Cost For Charging",
    "TT": "Total Spent Time For Charging",
    "FC": "Fixed Cost",
    "f": "Energy Function",
    "NS": "Number of Stopped Stations",
    "Percentage": "Battery Percentage In Each Segment",
    "Qmax": "Max kW to be charged with limited speed up to 20% of the battery",
    "Nmax": "Max kW to be charged with normal speed between 20-80%",
    "Wmax": "Max kW to be charged with limited over 80% of the battery",
    "Nt": "Nt",
    "N": "Amount of Charge With Normal Speed",
    "Q": "Amount Of Charge With Limited Speed Up To 20% of the battery",
    "W": "Amount Of Charge With Limited Speed over 80% of the battery",
}

# GAMS sonuçlarını işleme fonksiyonu
def load_gams_output(gdx_file_paths):
    ws = GamsWorkspace()
    model_path = "C:\\graduation_project\\initial_model.gms"
    job = ws.add_job_from_file(model_path)
    opt = ws.add_options()
    job.run(opt)
    
    all_variables = []
    all_scalars = []

    for gdx_file_path in gdx_file_paths:
        output_db = ws.add_database_from_gdx(gdx_file_path)

        variables = []
        scalars = []

        for symbol in output_db:
            if isinstance(symbol, GamsVariable):
                for rec in symbol:
                    if rec.level != 0:  # Değer kontrol
                        var_name = VARIABLE_NAME_MAPPING.get(symbol.name, symbol.name)
                        variables.append(f"{var_name} {rec.keys}: Amount={rec.level}")
            
        for symbol in job.out_db:
             if isinstance(symbol, GamsParameter):  
                if len(symbol.domains) == 0:
                    for rec in symbol:
                        scalars.append(f"{symbol.name}: Value={rec.value}")
        
        all_variables.extend(variables)
        all_scalars.extend(scalars)

    return all_variables, all_scalars

# Arayüz oluşturma
def create_gui():
    def update_output():
        output_list.delete(0, tk.END)  # Önceki sonuçları temizle
        scalar_list.delete(0, tk.END)

        try:
            gdx_file_paths = filedialog.askopenfilenames(
                title="Select GDX Files",
                filetypes=[("GDX Files", "*.gdx"), ("All Files", "*.*")]
            )
            if not gdx_file_paths:  # Kullanıcı dosya seçmezse
                output_list.insert(tk.END, "Error: No files selected.")
                return

            variables, scalars = load_gams_output(gdx_file_paths)

            # Değişkenleri yazdırma
            if variables:
                output_list.insert(tk.END, "=== Variables ===")
                for var in variables:
                    output_list.insert(tk.END, var)
            else:
                output_list.insert(tk.END, "Variables: Sıfırdan farklı değer yok.")

            # Scalar değerleri yazdırma
            if scalars:
                scalar_list.insert(tk.END, "=== Conditions ===")
                for scalar in scalars:
                    scalar_list.insert(tk.END, scalar)
            else:
                scalar_list.insert(tk.END, "Conditions: Hiç değer bulunamadı.")
        
        except Exception as e:
            output_list.insert(tk.END, f"Error: {e}")

    # Tkinter ana pencere
    root = tk.Tk()
    root.title("Route Decision Making Support Unit")
    root.geometry("800x600")

    # Başlık
    title_label = tk.Label(root, text="Outputs", font=("Arial", 16))
    title_label.pack(pady=10)

    # Çıktı kutusu
    output_frame = tk.Frame(root)
    output_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    scrollbar = tk.Scrollbar(output_frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    output_list = tk.Listbox(output_frame, font=("Courier", 12), yscrollcommand=scrollbar.set)
    output_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.config(command=output_list.yview)

    # Scalar kutusu
    scalar_frame = tk.Frame(root)
    scalar_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    scalar_scrollbar = tk.Scrollbar(scalar_frame)
    scalar_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    scalar_list = tk.Listbox(scalar_frame, font=("Courier", 12), yscrollcommand=scalar_scrollbar.set)
    scalar_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scalar_scrollbar.config(command=scalar_list.yview)

    # Run butonu
    run_button = ttk.Button(root, text="Run", command=update_output)
    run_button.pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    create_gui()
