from gams import *
import os

def run_gams():
    ws = GamsWorkspace()  
    model_path = "C:\\graduation_project\\initial_model.gms"  
    job = ws.add_job_from_file(model_path)
    opt = ws.add_options()
    job.run(opt)

   
    print("=== GAMS Çıktıları ===")
    
    
    if "z" in job.out_db:
        for rec in job.out_db["z"]:
            print(f"Optimal çözüm (z): {rec.level}")
    
    
    if "NS" in job.out_db:
        for rec in job.out_db["NS"]:
            print(f"NS: {rec.level}")
    
    
    if "Charge" in job.out_db:
        for rec in job.out_db["Charge"]:
            print(f"Charge: {rec.level}")
    
    
    print("\n Semboller")
    for symbol in job.out_db:
        print(f"Symbol: {symbol.name}")

        if isinstance(symbol, GamsVariable):
            has_nonzero= False
            for rec in symbol:
                if rec.level !=0:
                    if not has_nonzero:
                        print(f"Variable: {symbol.name}")
                        has_nonzero= True
                    print(f"{rec.keys}: Level={rec.level}")
            
        


if __name__ == "__main__":
    run_gams()
