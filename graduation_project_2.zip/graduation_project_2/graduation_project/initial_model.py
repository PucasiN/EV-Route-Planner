from gams import *
import os

def run_gams():
    ws = GamsWorkspace()  
    model_path = "C:\graduation_project\initial_model.gms"  

    
    job = ws.add_job_from_file(model_path)
    opt = ws.add_options()
    job.run(opt)

    
    for rec in job.out_db["z"]:
        print(f"Optimal çözüm: {rec.level}")
    for rec in job.out_db["NS"]:
        print(f"NS: {rec.level}")
    for rec in job.out_db["Charge"]:
        print(f"Charge: {rec.level}")
    
            
        
if __name__ == "__main__":
    run_gams()
