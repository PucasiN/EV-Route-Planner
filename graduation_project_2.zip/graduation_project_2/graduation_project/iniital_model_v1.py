from gams import *
import tkinter as tk
from tkinter import messagebox

# Sabit model dosyası yolu
MODEL_PATH = r"C:\graduation_project\initial_model.gms"

def run_gams():
    try:
        # GAMS modelini çalıştır
        ws = GamsWorkspace()
        job = ws.add_job_from_file(MODEL_PATH)
        opt = ws.add_options()
        job.run(opt)
        
        # Sonuçları al ve arayüzde göster
        results_text.delete("1.0", tk.END)  # Metin kutusunu temizle
        results_text.insert(tk.END, "Sonuçlar:\n")
        
        # 'z' sonuçları
        if "z" in job.out_db:
            results_text.insert(tk.END, "Optimal Çözümler:\n")
            for rec in job.out_db["z"]:
                results_text.insert(tk.END, f"  {rec.key(0)}: {rec.level}\n")
        else:
            results_text.insert(tk.END, "  'z' sonuçları bulunamadı.\n")
        
        # 'NS' sonuçları
        if "NS" in job.out_db:
            results_text.insert(tk.END, "\nNS Değerleri:\n")
            for rec in job.out_db["NS"]:
                results_text.insert(tk.END, f"  {rec.key(0)}: {rec.level}\n")
        else:
            results_text.insert(tk.END, "  'NS' sonuçları bulunamadı.\n")
        
        messagebox.showinfo("Başarılı", "GAMS modeli başarıyla çalıştırıldı.")
    
    except Exception as e:
        messagebox.showerror("Hata", f"Bir hata oluştu: {e}")

# Arayüz tasarımı
root = tk.Tk()
root.title("GAMS Model Çalıştırıcı")

# Butonlar ve metin alanı
frame = tk.Frame(root, padx=10, pady=10)
frame.pack()

run_button = tk.Button(frame, text="GAMS Modelini Çalıştır", command=run_gams)
run_button.pack(pady=10)

results_text = tk.Text(frame, width=60, height=20, wrap=tk.WORD, state=tk.NORMAL)
results_text.pack()

# Uygulamayı başlat
root.mainloop()
