import tkinter as tk
from tkinter import ttk
from gams import *

# Variable isimleri
VARIABLE_NAME_MAPPING = {
    "x": "Charging Occured at Station",
    "E": "Energy Level In Segment",
    "Charge": "Charging Amount In Station",
    "z": "Total Cost In Terms Of Money and Time",
    "sure": "Spent Time In Station",
    "TC": "Total Cost",
    "TT": "Total Spent Time",
    "FC": "Fixed Cost",
    "f": "Energy Function",
    "NS": "Number of Stopped Stations",
    "Percentage": "Battery Percentage In Each Segment",
    "Qmax": "Max kW to be charged with limited speed up to 20% of the battery",
    "Nmax": "Max kW to be charged with normal speed between 20-80%",
    "Wmax": "Max kW to be charged with limited over 80% of the battery",
    "Nt": "Nt",
    "N": "Amount of Charge With Normal Speed",
    "Q": "Amount Of Charge With Limited Speed Up To 20% of the battery",
    "W": "Amount Of Charge With Limited Speed over 80% of the battery",
}


MODEL_PATH = "C:\\graduation_project\\model_denemeler.gms"


GAMS_OUTPUTS = {
    "Charge Stations and Amounts": "C:\\graduation_project\\results_Charge.gdx",
    "Total Cost For Charging": "C:\\graduation_project\\results_TC.gdx",
    "Total Spent Time For Charging": "C:\\graduation_project\\results_TT.gdx",
    "Number Of Stations": "C:\\graduation_project\\results_NS.gdx",
}


def run_gams_and_load_output(gdx_path):
    ws = GamsWorkspace(system_directory="C:\\GAMS\\win64//24.1")
    job = ws.add_job_from_file(MODEL_PATH)
    opt = ws.add_options()
    job.run(opt)  
    output_db = ws.add_database_from_gdx(gdx_path)

    variables = []
    scalars = []

    for symbol in output_db:
        if isinstance(symbol, GamsVariable):
            for rec in symbol:
                if rec.level != 0:  
                    var_name = VARIABLE_NAME_MAPPING.get(symbol.name, symbol.name)
                    variables.append(f"{var_name} {rec.keys}: Amount={rec.level}")
    for symbol in job.out_db:
        if isinstance(symbol, GamsParameter):  
                if len(symbol.domains) == 0:
                    for rec in symbol:
                        scalars.append(f"{symbol.name}: Value={rec.value}")
    return variables, scalars


def create_gui():
    def show_data(scenario_name):
        output_list.delete(0, tk.END)
        scalar_list.delete(0, tk.END)
        try:
            gdx_path = GAMS_OUTPUTS[scenario_name]
            variables, scalars = run_gams_and_load_output(gdx_path)

            
            if variables:
                output_list.insert(tk.END, "Results:")
                for var in variables:
                    output_list.insert(tk.END, var)
            else:
                output_list.insert(tk.END, "No variables with non-zero values.")

            
            if scalars:
                scalar_list.insert(tk.END, "Conditions: ")
                for scalar in scalars:
                    scalar_list.insert(tk.END, scalar)
            else:
                scalar_list.insert(tk.END, "No scalar values found.")
        except Exception as e:
            output_list.insert(tk.END, f"Error: {e}")
            
    def show_all_data():
        output_list.delete(0, tk.END)
        scalar_list.delete(0, tk.END)
        for scenario_name, gdx_path in GAMS_OUTPUTS.items():
            try:
                variables, scalars = run_gams_and_load_output(gdx_path)

                
                if variables:
                    output_list.insert(tk.END, f"=== Variables for {scenario_name} ===")
                    for var in variables:
                        output_list.insert(tk.END, var)
                else:
                    output_list.insert(tk.END, f"No variables with non-zero values for {scenario_name}.")

                
                if scalars:
                    scalar_list.insert(tk.END, f"=== Scalars for {scenario_name} ===")
                    for scalar in scalars:
                        scalar_list.insert(tk.END, scalar)
                else:
                    scalar_list.insert(tk.END, f"No scalar values found for {scenario_name}.")
            except Exception as e:
                output_list.insert(tk.END, f"Error for {scenario_name}: {e}")
    

   
    root = tk.Tk()
    root.title("Route Decision Making Support Unit")
    root.geometry("800x600")

    
    title_label = tk.Label(root, text="Route Decision Making Support Unit", font=("Arial", 16))
    title_label.pack(pady=10)

    
    buttons_frame = tk.Frame(root)
    buttons_frame.pack(pady=10)

    for scenario_name in GAMS_OUTPUTS:
        button = ttk.Button(
            buttons_frame, 
            text=scenario_name, 
            command=lambda name=scenario_name: show_data(name)
        )
        button.pack(side=tk.LEFT, padx=10)
        
    all_button = ttk.Button(
        buttons_frame,
        text="Show All The Data",
        command=show_all_data
    )
    all_button.pack(side=tk.LEFT, padx=10)

        
    output_frame = tk.Frame(root)
    output_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

    
    variable_frame = tk.Frame(output_frame)
    variable_frame.pack(side=tk.LEFT, padx=5, fill=tk.BOTH, expand=True)

    variable_scrollbar = tk.Scrollbar(variable_frame)
    variable_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    output_list = tk.Listbox(variable_frame, font=("Courier", 12), yscrollcommand=variable_scrollbar.set)
    output_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    variable_scrollbar.config(command=output_list.yview)

    
    scalar_frame = tk.Frame(output_frame, height=200)
    scalar_frame.pack(side=tk.RIGHT, padx=5, fill=tk.BOTH)

    scalar_scrollbar = tk.Scrollbar(scalar_frame)
    scalar_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    scalar_list = tk.Listbox(scalar_frame, font=("Courier", 12), yscrollcommand=scalar_scrollbar.set, height=10)
    scalar_list.pack(side=tk.LEFT, fill=tk.BOTH, expand=False)
    scalar_scrollbar.config(command=scalar_list.yview)

    root.mainloop()

if __name__ == "__main__":
    create_gui()
