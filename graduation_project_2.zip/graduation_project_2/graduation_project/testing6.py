from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtWidgets import (QApplication, QWidget, QLabel, QFrame, 
                            QMessageBox, QVBoxLayout, QHBoxLayout, 
                            QGridLayout, QGroupBox, QPushButton, 
                            QTextEdit, QSpinBox, QComboBox, 
                            QProgressBar, QDialog, QScrollArea)
from PyQt6.QtGui import QFont, QPixmap
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import pandas as pd
import os
from datetime import datetime
import subprocess

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(1000, 650)
        Form.setWindowTitle("EV Route Planner")
        
        # Main layout with some spacing
        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        
        # Create header banner with enhanced title
        self.header = QWidget(Form)
        self.header.setMinimumSize(QtCore.QSize(0, 100))
        self.header.setStyleSheet("background-color: #4CAF50;")
        
        # Main header layout
        header_layout = QVBoxLayout(self.header)
        header_layout.setContentsMargins(20, 10, 20, 10)
        header_layout.setSpacing(5)
        
        # Main title with larger, more prominent font
        self.title_label = QLabel("EV ROUTE PLANNER", self.header)
        self.title_label.setStyleSheet("""
            color: white;
            font-weight: bold;
            qproperty-alignment: AlignCenter;
        """)
        self.title_label.setFont(QFont("Segoe UI", 28, QFont.Weight.Bold))
        
        # Subtitle with improved styling
        self.subtitle = QLabel("Plan Your Electric Vehicle Journey Efficiently", self.header)
        self.subtitle.setStyleSheet("""
            color: #e8f5e9;
            font-size: 14pt;
            qproperty-alignment: AlignCenter;
            font-weight: 500;
        """)
        self.subtitle.setFont(QFont("Segoe UI", 12))
        
        # Add decorative line
        self.decorative_line = QFrame(self.header)
        self.decorative_line.setFrameShape(QFrame.Shape.HLine)
        self.decorative_line.setStyleSheet("""
            QFrame {
                color: rgba(255, 255, 255, 0.3);
                background-color: rgba(255, 255, 255, 0.3);
                border: none;
                height: 2px;
                margin: 5px 50px;
            }
        """)
        
        header_layout.addWidget(self.title_label)
        header_layout.addWidget(self.decorative_line)
        header_layout.addWidget(self.subtitle)
        
        self.verticalLayout.addWidget(self.header)

        # Main content widget with grey background
        self.contentWidget = QWidget(Form)
        self.contentWidget.setStyleSheet("background-color: #f5f5f5;")
        self.contentLayout = QVBoxLayout(self.contentWidget)
        self.contentLayout.setContentsMargins(20, 20, 20, 20)
        self.contentLayout.setSpacing(15)
        
        # Inputs group box - white with grey border
        self.groupBox = QGroupBox(parent=self.contentWidget)
        self.groupBox.setTitle("Journey Parameters")
        self.groupBox.setStyleSheet("""
            QGroupBox {
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
                color: #555;
                background-color: white;
                font-size: 12pt;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
                color: #555;
            }
        """)
        
        self.gridLayout = QGridLayout(self.groupBox)
        self.gridLayout.setVerticalSpacing(12)
        self.gridLayout.setHorizontalSpacing(20)

        # Battery level widget
        self.label_battery = QLabel("Battery Level (%)", parent=self.groupBox)
        self.battery_widget = QWidget(parent=self.groupBox)
        self.battery_layout = QHBoxLayout(self.battery_widget)
        self.battery_layout.setContentsMargins(0, 0, 0, 0)
        self.battery_layout.setSpacing(10)
        self.spin_battery = QSpinBox(parent=self.battery_widget)
        self.spin_battery.setRange(0, 100)
        self.spin_battery.setValue(50)
        self.spin_battery.setSuffix("%")
        self.progress_battery = QProgressBar(parent=self.battery_widget)
        self.progress_battery.setRange(0, 100)
        self.progress_battery.setValue(self.spin_battery.value())
        self.progress_battery.setTextVisible(True)
        self.progress_battery.setStyleSheet("""
            QProgressBar {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                text-align: center;
                height: 20px;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                width: 10px;
            }
        """)
        self.battery_layout.addWidget(self.spin_battery)
        self.battery_layout.addWidget(self.progress_battery)
        self.gridLayout.addWidget(self.label_battery, 0, 0)
        self.gridLayout.addWidget(self.battery_widget, 0, 1)

        # Temperature input
        self.label_temp = QLabel("Temperature (°C)", parent=self.groupBox)
        self.spin_temp = QSpinBox(parent=self.groupBox)
        self.spin_temp.setRange(-20, 50)
        self.gridLayout.addWidget(self.label_temp, 1, 0)
        self.gridLayout.addWidget(self.spin_temp, 1, 1)

        # Desired battery level
        self.label_desired = QLabel("Desired Battery (%)", parent=self.groupBox)
        self.spin_desired = QSpinBox(parent=self.groupBox)
        self.spin_desired.setRange(0, 100)
        self.spin_desired.setValue(80)
        self.spin_desired.setSuffix("%")
        self.gridLayout.addWidget(self.label_desired, 2, 0)
        self.gridLayout.addWidget(self.spin_desired, 2, 1)

        # Start city
        self.label_start = QLabel("Start City", parent=self.groupBox)
        self.combo_start = QComboBox(parent=self.groupBox)
        self.combo_start.addItems(["Istanbul", "Ankara", "Antalya", "Kocaeli", "Konya", "Izmir", "Bursa"])
        self.gridLayout.addWidget(self.label_start, 3, 0)
        self.gridLayout.addWidget(self.combo_start, 3, 1)

        # Destination city
        self.label_end = QLabel("Destination City", parent=self.groupBox)
        self.combo_end = QComboBox(parent=self.groupBox)
        self.combo_end.addItems(["Istanbul", "Ankara", "Antalya", "Kocaeli", "Konya", "Izmir", "Bursa"])
        self.gridLayout.addWidget(self.label_end, 4, 0)
        self.gridLayout.addWidget(self.combo_end, 4, 1)
        
        # Start Planning button - Changed to light green
        self.btn_start = QPushButton("Start Planning", parent=self.groupBox)
        self.btn_start.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 15px;
                font-weight: bold;
                min-width: 160px;
                font-size: 11pt;
            }
            QPushButton:hover {
                background-color: #43A047;
            }
            QPushButton:pressed {
                background-color: #388E3C;
            }
        """)
        self.gridLayout.addWidget(self.btn_start, 5, 0, 1, 2)  # Span 2 columns

        self.contentLayout.addWidget(self.groupBox)

        # Results group box - Initially hidden
        self.groupBox_3 = QGroupBox(parent=self.contentWidget)
        self.groupBox_3.setTitle("Route Analysis Results")
        self.groupBox_3.setStyleSheet("""
            QGroupBox {
                border: 1px solid #e0e0e0;
                border-radius: 8px;
                margin-top: 10px;
                padding-top: 15px;
                font-weight: bold;
                color: #555;
                background-color: white;
                font-size: 12pt;
            }
        """)
        self.horizontalLayout = QHBoxLayout(self.groupBox_3)
        self.horizontalLayout.setSpacing(15)

        # Button column
        self.button_layout = QVBoxLayout()
        self.button_layout.setSpacing(10)

        # Style buttons with light green
        button_style = """
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 10px 15px;
                font-weight: bold;
                min-width: 160px;
                font-size: 11pt;
            }
            QPushButton:hover {
                background-color: #43A047;
            }
            QPushButton:pressed {
                background-color: #388E3C;
            }
        """

        self.btn_stations = QPushButton("Number of Stations", parent=self.groupBox_3)
        self.btn_time = QPushButton("Total Travel Time", parent=self.groupBox_3)
        self.btn_charging = QPushButton("Charging Stations", parent=self.groupBox_3)
        self.btn_cost = QPushButton("Total Trip Cost", parent=self.groupBox_3)
        self.btn_all = QPushButton("Show All Results", parent=self.groupBox_3)
        self.btn_graph = QPushButton("View Route Graph", parent=self.groupBox_3)

        # Disable result buttons initially
        self.btn_stations.setEnabled(False)
        self.btn_time.setEnabled(False)
        self.btn_charging.setEnabled(False)
        self.btn_cost.setEnabled(False)
        self.btn_all.setEnabled(False)
        self.btn_graph.setEnabled(False)

        for btn in [self.btn_stations, self.btn_time, self.btn_charging, self.btn_cost, self.btn_all, self.btn_graph]:
            btn.setStyleSheet(button_style)
            self.button_layout.addWidget(btn)

        self.horizontalLayout.addLayout(self.button_layout)
        
        # Results display area
        self.label_all_output = QTextEdit(parent=self.groupBox_3)
        self.label_all_output.setPlaceholderText("Press 'Start Planning' to begin your route analysis")
        self.label_all_output.setReadOnly(True)
        self.label_all_output.setStyleSheet("""
            QTextEdit {
                background-color: white;
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 12px;
                font-size: 11pt;
                color: #555;
            }
        """)
        self.horizontalLayout.addWidget(self.label_all_output)
        
        # Hide results section initially
        self.groupBox_3.setVisible(False)
        self.contentLayout.addWidget(self.groupBox_3)
        
        # Add status bar with light green
        self.status_bar = QFrame(Form)
        self.status_bar.setFrameShape(QFrame.Shape.StyledPanel)
        self.status_bar.setFrameShadow(QFrame.Shadow.Raised)
        self.status_bar.setStyleSheet("background-color: #4CAF50; color: white; padding: 5px;")
        self.status_label = QLabel("Ready to plan your EV journey!", self.status_bar)
        self.status_label.setStyleSheet("color: white;")
        
        status_layout = QHBoxLayout(self.status_bar)
        status_layout.addWidget(self.status_label)
        status_layout.setContentsMargins(10, 0, 10, 0)
        
        self.verticalLayout.addWidget(self.contentWidget)
        self.verticalLayout.addWidget(self.status_bar)
        
        # Connect signals
        self.spin_battery.valueChanged.connect(self.progress_battery.setValue)
        QtCore.QMetaObject.connectSlotsByName(Form)


class EVRoutePlanner(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        # Get the directory where the script is located
        self.script_dir = os.path.dirname(os.path.abspath(__file__))
        self.gams_path = self.script_dir  # Use script directory for GAMS files
        
        # Set the GAMS executable path
        self.gams_executable = r"C:\win64\24.1\gams.exe"
        
        # Connect buttons
        self.ui.btn_start.clicked.connect(self.start_planning)
        self.ui.btn_stations.clicked.connect(self.show_stations)
        self.ui.btn_time.clicked.connect(self.show_time)
        self.ui.btn_charging.clicked.connect(self.show_charging)
        self.ui.btn_cost.clicked.connect(self.show_cost)
        self.ui.btn_all.clicked.connect(self.show_all)
        self.ui.btn_graph.clicked.connect(self.show_graph)
    
    def get_excel_path(self):
        """Generate file path based on selected cities"""
        start = self.ui.combo_start.currentText()
        end = self.ui.combo_end.currentText()
        
        # Remove spaces and dashes, convert to lowercase
        start_clean = start.replace(" ", "").replace("-", "").lower()
        end_clean = end.replace(" ", "").replace("-", "").lower()
        
        filename = f"{start_clean}{end_clean}.xlsx"
        # Use script directory instead of old base_path
        return os.path.join(self.script_dir, filename)
    
    def get_gams_filename(self):
        """Generate GAMS filename based on selected cities"""
        start = self.ui.combo_start.currentText()
        end = self.ui.combo_end.currentText()
        
        # Remove spaces and dashes, convert to lowercase
        start_clean = start.replace(" ", "").replace("-", "").lower()
        end_clean = end.replace(" ", "").replace("-", "").lower()
        
        return f"{start_clean}{end_clean}"
    
    def validate_file(self, path):
        """Check if file exists and is valid"""
        if not os.path.exists(path):
            QMessageBox.critical(
                self, 
                "File Not Found", 
                f"Route data file not found:\n{path}\n\n"
                "Please ensure you've selected valid cities and the route file exists."
            )
            self.ui.status_label.setText(f"Error: File not found - {os.path.basename(path)}")
            return False
        return True

    def run_gams_model(self):
        """Run the GAMS model for the selected route"""
        gams_base = self.get_gams_filename()
        
        # Try different file extensions for GAMS files
        possible_extensions = ['.gms', '.~gm']
        gams_filepath = None
        actual_filename = None
        
        for ext in possible_extensions:
            candidate = os.path.join(self.gams_path, gams_base + ext)
            if os.path.exists(candidate):
                gams_filepath = candidate
                actual_filename = os.path.basename(candidate)
                break
        
        # Validate that GAMS file exists
        if not gams_filepath:
            QMessageBox.critical(
                self, 
                "GAMS File Not Found", 
                f"GAMS model file not found for:\n{gams_base}\n\n"
                f"Tried extensions: {', '.join(possible_extensions)}\n"
                "Please ensure the model file exists for the selected route."
            )
            self.ui.status_label.setText(f"Error: GAMS file not found for {gams_base}")
            return False
        
        try:
            # Run the GAMS model
            self.ui.status_label.setText(f"Running GAMS model: {actual_filename}...")
            QApplication.processEvents()  # Update UI immediately
            
            # Use the full path to the GAMS executable
            subprocess.run([self.gams_executable, actual_filename], 
                           cwd=self.gams_path, 
                           check=True)
            
            self.ui.status_label.setText(f"GAMS model completed: {actual_filename}")
            return True
        except subprocess.CalledProcessError as e:
            QMessageBox.critical(
                self, 
                "GAMS Execution Error", 
                f"Failed to run GAMS model:\n{str(e)}\n\n"
                "Please check the GAMS installation and model file."
            )
            self.ui.status_label.setText(f"Error running GAMS: {actual_filename}")
            return False
        except Exception as e:
            QMessageBox.critical(
                self, 
                "GAMS Error", 
                f"Unexpected error running GAMS model:\n{str(e)}"
            )
            self.ui.status_label.setText(f"GAMS error: {actual_filename}")
            return False

    def read_excel_data(self):
        # Get dynamic path based on user selection
        self.excel_path = self.get_excel_path()
        
        # Validate file exists before processing
        if not self.validate_file(self.excel_path):
            return None
        
        data = {}
        try:
            # Read all sheets with proper index handling
            # For scalar values (single numbers)
            data['ns'] = self.read_scalar('NS')
            data['tt'] = self.read_scalar('TT')
            data['tc'] = self.read_scalar('TC')
            
            # For matrix data
            data['charge'] = self.read_matrix('charge')
            
            # Convert minutes to hours and minutes
            hours = data['tt'] // 60
            minutes = data['tt'] % 60
            data['tt_formatted'] = f"{int(hours)} hours {int(minutes)} minutes"
            
            return data
        except Exception as e:
            QMessageBox.critical(
                self, 
                "Data Read Error", 
                f"Error processing route data:\n{str(e)}\n\n"
                "Please ensure the Excel file format is correct."
            )
            self.ui.status_label.setText(f"Error reading data from {os.path.basename(self.excel_path)}")
            return None

    def read_scalar(self, sheet_name):
        """Read a single value from a sheet"""
        df = pd.read_excel(self.excel_path, sheet_name=sheet_name, header=None)
        
        # Find the first numeric value in the entire sheet
        for row in df.values:
            for cell in row:
                try:
                    return float(cell)
                except (ValueError, TypeError):
                    continue
        raise ValueError(f"No numeric value found in sheet {sheet_name}")

    def read_matrix(self, sheet_name):
        """Read matrix data from a sheet, handling index columns"""
        df = pd.read_excel(self.excel_path, sheet_name=sheet_name)
        
        # Remove any "Unnamed" index columns
        df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
        
        # Convert to numeric, ignoring errors
        return df.apply(pd.to_numeric, errors='coerce')

    def start_planning(self):
        """Collect inputs, create include file, run GAMS"""
        # Get user inputs
        battery = self.ui.spin_battery.value()
        temp = self.ui.spin_temp.value()
        desired = self.ui.spin_desired.value()

        # Prepare include file name based on selected cities
        start = self.ui.combo_start.currentText()
        end = self.ui.combo_end.currentText()
        start_clean = start.replace(" ", "").replace("-", "").lower()
        end_clean = end.replace(" ", "").replace("-", "").lower()
        base_name = "input_parameter"
        inc_filename = f"{base_name}.inc"
        inc_path = os.path.join(self.script_dir, inc_filename)

        try:
            # Create simple include file (var=value; format)
            with open(inc_path, 'w', encoding='utf-8') as f:
                f.write(f'Binit={battery};\n')
                f.write(f'OutsideT={temp};\n')
                f.write(f'Batterylevelf={desired};\n')

            # Show success and run GAMS after a short delay
            self.ui.status_label.setText(f"Created include file: {inc_filename}")
            QtCore.QTimer.singleShot(1500, self.run_gams_after_delay)

        except Exception as e:
            error_msg = f"Could not create include file:\n{str(e)}"
            QMessageBox.critical(self, "File Error", error_msg)
            self.ui.status_label.setText(f"Error: {error_msg}")

    def run_gams_after_delay(self):
        """Run GAMS after ensuring files are created"""
        try:
            if not self.run_gams_model():
                return
                
            # Hide the Start Planning button
            self.ui.btn_start.setVisible(False)
            
            # Show results section
            self.ui.groupBox_3.setVisible(True)
            
            # Enable result buttons
            self.ui.btn_stations.setEnabled(True)
            self.ui.btn_time.setEnabled(True)
            self.ui.btn_charging.setEnabled(True)
            self.ui.btn_cost.setEnabled(True)
            self.ui.btn_all.setEnabled(True)
            self.ui.btn_graph.setEnabled(True)
            
            # Clear previous results
            self.ui.label_all_output.clear()
            self.ui.label_all_output.setPlaceholderText("Select a result option to view details")
            
            # Show final status
            self.ui.status_label.setText(f"GAMS execution completed! Results available.")
            
            # Automatically show the route image
            self.show_route_image()
            
        except Exception as e:
            error_msg = f"GAMS execution failed:\n{str(e)}"
            QMessageBox.critical(self, "GAMS Error", error_msg)
            self.ui.status_label.setText(f"Error: {error_msg}")

    def show_route_image(self):
        """Display the route image after GAMS run."""
        start = self.ui.combo_start.currentText()
        end = self.ui.combo_end.currentText()
        start_clean = start.replace(" ", "").replace("-", "").lower()
        end_clean   = end.replace(" ", "").replace("-", "").lower()
        img_filename = f"{start_clean}{end_clean}.jpg"
        img_path = os.path.join(self.script_dir, img_filename)
        
        if not os.path.exists(img_path):
            QMessageBox.warning(
                self,
                "Image Not Found",
                f"Route image not found:\n{img_path}"
            )
            return

        # Create a dialog to display the image
        dlg = QDialog(self)
        dlg.setWindowTitle(f"Route Visualization: {start} → {end}")

        # Create layout and scroll area
        layout = QVBoxLayout(dlg)
        scroll = QScrollArea(dlg)
        scroll.setWidgetResizable(True)  # Allow scrolling for large images

        # Create label to display the image
        label = QLabel()
        pixmap = QPixmap(img_path)
        # make the label scale its pixmap to its own size
        label.setScaledContents(True)
        label.setPixmap(pixmap)
        label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        scroll.setWidget(label)

        layout.addWidget(scroll)
        
        # Show the dialog
        dlg.show()
        # ensure the dialog is sized before we force a redraw
        dlg.resize(800, 600)

    def show_stations(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Number of Charging Stations: {int(data['ns'])}"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed stations from {filename}")

    def show_time(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Total Travel Time: {data['tt_formatted']}"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed travel time from {filename}")

    def show_charging(self):
        if data := self.read_excel_data():
            # Get the charge DataFrame
            charge_df = data['charge']
            
            # Create a list to store charging station info
            stations = []
            for segment_index in charge_df.index:
                for station_col in charge_df.columns:
                    charge_value = charge_df.loc[segment_index, station_col]
                    if charge_value > 0:
                        segment = int(segment_index)
                        station = int(station_col)
                        stations.append((segment, station, charge_value))
            
            # Sort by segment number
            stations.sort(key=lambda x: x[0])
            
            # Format the stations
            station_info = [
                f"Segment {seg}, Station {stat}: {val:.2f} kWh"
                for seg, stat, val in stations
            ]
            
            self.ui.label_all_output.setText(
                "Charging Stations Along Route:\n\n" + 
                ("\n".join(station_info) if station_info else "No charging stations used on this route")
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed charging info from {filename}")
    
    def show_cost(self):
        if data := self.read_excel_data():
            self.ui.label_all_output.setText(
                f"Total Trip Cost: {data['tc']:.2f} TL"
            )
            filename = os.path.basename(self.excel_path)
            self.ui.status_label.setText(f"Displayed trip cost from {filename}")

    def show_all(self):
        if data := self.read_excel_data():
            # Get current parameters from UI
            current_battery = self.ui.spin_battery.value()
            current_temp = self.ui.spin_temp.value()
            desired_battery = self.ui.spin_desired.value()
            start_city = self.ui.combo_start.currentText()
            end_city = self.ui.combo_end.currentText()
            
            try:
                # Get charging station details with proper formatting
                charge_df = data['charge']
                stations = []
                for segment_index in charge_df.index:
                    for station_col in charge_df.columns:
                        charge_value = charge_df.loc[segment_index, station_col]
                        if charge_value > 0:
                            segment = int(segment_index)
                            station = int(station_col)
                            stations.append((segment, station, charge_value))
                
                # Sort by segment number
                stations.sort(key=lambda x: x[0])
                
                # Format stations with bullet points
                station_info = [
                    f"  - Segment {seg}, Station {stat}: {val:.2f} kWh"
                    for seg, stat, val in stations
                ]
                
                # Battery data extraction
                battery_info = "  Battery data not available"
                try:
                    battery_df = pd.read_excel(self.excel_path, sheet_name='batterypercentage')
                    
                    # Remove any index columns
                    battery_df = battery_df.loc[:, ~battery_df.columns.str.contains('^Unnamed')]
                    
                    # Get battery levels from first row
                    if not battery_df.empty:
                        battery_levels = battery_df.iloc[0].tolist()
                        # Build battery info
                        battery_info = "\n".join(
                            [f"  - Segment {i+1}: {val:.1f}%" 
                             for i, val in enumerate(battery_levels)]
                        )
                    else:
                        battery_info = "  No valid battery data found"
                except Exception as e:
                    battery_info = f"  Error reading battery data: {str(e)}"
                
                # Build the output string
                output_text = (
                    "EV Route Planner - Complete Analysis\n\n"
                    f"Route: {start_city} → {end_city}\n"
                    f"Data Source: {os.path.basename(self.excel_path)}\n\n"
                    f"Current Battery: {current_battery}%\n"
                    f"Desired Battery: {desired_battery}%\n"
                    f"Temperature: {current_temp}°C\n\n"
                    f"Number of Charging Stations: {int(data['ns'])}\n"
                    f"Total Travel Time: {data['tt_formatted']}\n"
                    f"Total Trip Cost: {data['tc']:.2f} TL\n\n"
                    "Charging Stations:\n" +
                    ("\n".join(station_info) if station_info else "  None") + "\n\n"
                    "Battery Levels by Segment:\n" +
                    battery_info
                )
                
                self.ui.label_all_output.setText(output_text)
                filename = os.path.basename(self.excel_path)
                self.ui.status_label.setText(f"Displayed full analysis from {filename}")
            
            except Exception as e:
                QMessageBox.critical(self, "Data Processing Error", f"Failed to process data:\n{str(e)}")
                self.ui.status_label.setText("Error displaying results")
            
    def show_graph(self):
        # Get the current Excel file path
        excel_path = self.get_excel_path()
        if not os.path.exists(excel_path):
            QMessageBox.critical(self, "File Not Found", f"Excel file not found: {excel_path}")
            self.ui.status_label.setText("Error: Excel file not found for graph")
            return
        
        try:
            # Read battery percentage data
            battery_df = pd.read_excel(excel_path, sheet_name='batterypercentage')
            battery_values = battery_df.iloc[0].values  # Get the first row values
            
            # Read energy level data
            energy_df = pd.read_excel(excel_path, sheet_name='energylevel')
            energy_values = energy_df.iloc[0].values  # Get the first row values
            
            # Create distances based on the number of data points (each segment = 10km)
            distances = [i * 10 for i in range(1, len(battery_values) + 1)]
            
            # Create the figure and axes
            fig, ax1 = plt.subplots(figsize=(8, 5))
            
            # Plot battery percentage
            ax1.plot(distances, battery_values, color='#4CAF50', marker='o', 
                    label='Battery Level (%)', linewidth=2)
            ax1.set_xlabel("Distance (km)", fontsize=10)
            ax1.set_ylabel("Battery Level (%)", color='#4CAF50', fontsize=10)
            ax1.tick_params(axis='y', labelcolor='#4CAF50')
            ax1.set_ylim(0, 100)  # Battery percentage range
            
            # Create a second y-axis for energy level
            ax2 = ax1.twinx()
            ax2.plot(distances, energy_values, color='#2196F3', marker='s', 
                    label='Energy Level (kWh)', linewidth=2)
            ax2.set_ylabel("Energy Level (kWh)", color='#2196F3', fontsize=10)
            ax2.tick_params(axis='y', labelcolor='#2196F3')
            
            # Set title
            start_city = self.ui.combo_start.currentText()
            end_city = self.ui.combo_end.currentText()
            plt.title(f"EV Route Analysis: {start_city} to {end_city}", fontsize=12, pad=20)
            
            # Add legend
            lines1, labels1 = ax1.get_legend_handles_labels()
            lines2, labels2 = ax2.get_legend_handles_labels()
            ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
            
            # Display the graph
            fig.tight_layout()
            plt.show()
            self.ui.status_label.setText("Displayed route analysis graph")
            
        except Exception as e:
            QMessageBox.critical(self, "Graph Error", f"Could not generate graph:\n{str(e)}")
            self.ui.status_label.setText("Error generating graph")


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    
    # Set application style
    app.setStyle('Fusion')
    
    # Create and show main window
    window = EVRoutePlanner()
    window.show()
    sys.exit(app.exec())