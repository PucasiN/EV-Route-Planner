# Battery capacity widget (NEW, goes under Desired Battery)
self.label_capacity = QLabel("Battery Capacity (kWh)", parent=self.groupBox)
self.spin_capacity = QSpinBox(parent=self.groupBox)
self.spin_capacity.setRange(0, 200)           # adjust max as you like
self.spin_capacity.setValue(75)               # default capacity
self.spin_capacity.setSuffix(" kWh")
self.gridLayout.addWidget(self.label_capacity, 3, 0)
self.gridLayout.addWidget(self.spin_capacity, 3, 1)
